package com.banking.accountservice;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.banking.accountservice.dao.AccountDao;
import com.banking.accountservice.model.Account;
import com.banking.accountservice.service.AccountService;

@SpringBootTest
class AccountServiceApplicationTests {

	
	@Autowired
	AccountService accService;
	
	@MockBean
	AccountDao dao;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	public void testAddAccount() {
		Account acc = new Account(111l, 568d, "pune", LocalDate.now(), "saving");
		Mockito.when(dao.save(acc)).thenReturn(acc);
		boolean msg = accService.addAccount(acc);
		assertEquals(true, msg);
	}

	@Test
	public void testUpdateAccount() {
		Account account = new Account(222l, 568d, "pune", LocalDate.now(), "saving");
		Mockito.when(dao.save(account)).thenReturn(account);
		boolean msg = accService.updateAccount(account);
		assertEquals(true, msg);
	}
	
//	@Test
//	public void testDeleteAccount() {
//		Account acc = new Account(111l, 568d, "pune", LocalDate.now(), "saving");
//		 accService.createAccount(acc);
//		String msg = accService.deleteAccount(111);
//		assertEquals("Account deleted successful", msg);
//	}

}
