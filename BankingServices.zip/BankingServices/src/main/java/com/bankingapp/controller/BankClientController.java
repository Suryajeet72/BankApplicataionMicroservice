package com.bankingapp.controller;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.bankingapp.models.Account;
import com.bankingapp.models.AccountDTO;
import com.bankingapp.models.ApplicationUser;
import com.bankingapp.models.Customer;
import com.bankingapp.models.CustomerDto;
import com.bankingapp.models.Transaction;
import com.bankingapp.models.TransactionDTO;

@Controller
public class BankClientController {

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/")
	public String home() {
		return "home";
	}

	@GetMapping("/createCustomer")
	public String createCustomer() {
		return "CreateCustomer";

	}

	@GetMapping("/createAccount")
	public String createAccount() {
		return "CreateAccount";

	}

	@GetMapping("/createTransaction")
	public String createTransaction() {
		return "CreateTransaction";

	}

	@GetMapping("/depositAccount")
	public String depositAccount() {
		return "DepositList";

	}

	@GetMapping("/withdrawAccount")
	public String withdrawAccount() {
		return "WithdrawList";

	}

	@GetMapping("/fundtransferAccount")
	public String fundtransferAccount() {
		return "FundTransferList";

	}

	@PostMapping("/userlogin")
	public String userLogin(@RequestParam("username") String username, @RequestParam("password") String password,
			Model model, HttpSession session) {
		System.out.println(username);
		System.out.println(password);
		ApplicationUser user = new ApplicationUser();

		user.setUsername(username);
		user.setPassword(password);
		int status;
		try {

			ResponseEntity<ApplicationUser> res = restTemplate.postForEntity("http://localhost:8090/authservice/auth",
					user, ApplicationUser.class);
			ApplicationUser userObj = (ApplicationUser) res.getBody();
			System.out.println(userObj);
			session.setAttribute("userId", userObj.getUserId());
			status = res.getStatusCodeValue();
			System.out.println(res.getStatusCodeValue());
			return "redirect:/customers";
		} catch (Exception e) {

			status = 400;
			model.addAttribute("message", "UserName and Password invalid" + e);

			return "home";
		}
	}

	
	// All Customer List
	@GetMapping("/customers")
	public String getAllCustomer(HttpSession session) {
		CustomerDto cusdto = restTemplate.getForObject("http://localhost:8084/customerservice/customers",
				CustomerDto.class);
		// model.addAttribute("ProductList",dto.getList());
		session.setAttribute("CustomerList", cusdto.getList());
		return "customerList";
	}

	
	// All Account List
	@GetMapping("/accounts")
	public String getAllAccount(HttpSession session) {
		AccountDTO dto = new AccountDTO();
		try {
			dto = restTemplate.getForObject("http://localhost:8085/accountservice/accounts", AccountDTO.class);
			// model.addAttribute("ProductList",dto.getList());
			List<Account> list = dto.getList();
			System.out.println(list);
			session.setAttribute("AccountList", list);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return "accountList";
		}
		return "accountList";
	}

	
	// All transaction List
	@GetMapping("/transactions")
	public String getAllTransaction(HttpSession session) {
		TransactionDTO dto = new TransactionDTO();
		try {
			dto = restTemplate.getForObject("http://localhost:8095/transactionservice/transactions",
					TransactionDTO.class);
			// model.addAttribute("ProductList",dto.getList());
			List<Transaction> list = dto.getList();
			System.out.println(list);
			session.setAttribute("TransactionList", list);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return "transactionList";
		}
		return "transactionList";
	}

	
	// Adding Customer
	@PostMapping("create")
	public String addCustomer(@RequestParam("cusId") int cusId, @RequestParam("cusName") String cusName,
			@RequestParam("cusEmail") String cusEmail, @RequestParam("cusMob") long cusMob,
			@RequestParam("cusAadhar") long cusAadhar, @RequestParam("cusPermaAdd") String cusPermaAdd,
			@RequestParam("cusResiAdd") String cusResiAdd, @RequestParam("cusDob") String cusDob, Model model,
			HttpSession session) {
		int userId = 0;
		userId = (int) session.getAttribute("userId");
		if (userId == 0) {
			return "SessionExpired";
		}
		System.out.println(cusId);
		Customer cus = new Customer();
		cus.setCusId(cusId);
		cus.setCusName(cusName);
		cus.setCusEmail(cusEmail);
		cus.setCusMob(cusMob);
		cus.setCusAadhar(cusAadhar);
		cus.setCusPrmaAdd(cusPermaAdd);
		cus.setCusResiAdd(cusResiAdd);
		cus.setCusDob(cusDob);

		int status;
		try {

			ResponseEntity<Customer> res = restTemplate.postForEntity("http://localhost:8084/customerservice/create",
					cus, Customer.class);
			Customer customer = (Customer) res.getBody();
			System.out.println(customer);

			System.out.println(res.getStatusCodeValue());
			return "redirect:/customers";
		} catch (Exception e) {

			status = 400;
			model.addAttribute("message", "UserName and Password invalid" + e);

			return "home";
		}

	}

	
	// Adding Account
	@PostMapping("createAcc")
	public String addAccount(@RequestParam("accNumber") long accNumber, @RequestParam("accBalance") double accBalance,
			@RequestParam("accBranch") String accBranch,
			// @RequestParam("accOpenDate") LocalDate accOpenDate,
			@RequestParam("accType") String accType, Model model, HttpSession session) {
		int userId = 0;
		userId = (int) session.getAttribute("userId");
		if (userId == 0) {
			return "SessionExpired";
		}
	
		Account acc = new Account();
		acc.setAccNumber(accNumber);
		acc.setAccBalance(accBalance);
		acc.setAccBranch(accBranch);
	
		acc.setAccType(accType);

		int status;
		try {

			ResponseEntity<Account> res = restTemplate.postForEntity("http://localhost:8085/accountservice/create", acc,
					Account.class);
			Account account = (Account) res.getBody();
			System.out.println(account);

			System.out.println(res.getStatusCodeValue());
			return "redirect:/accounts";
		} catch (Exception e) {

			status = 400;
			model.addAttribute("message", "UserName and Password invalid" + e);

			return "home";
		}

	}

	
	// Adding Transaction
	@PostMapping("createtran")
	public String addTransaction(@RequestParam("fromAccNumber") long fromAccNumber,
			@RequestParam("toAccNumber") long toAccNumber, @RequestParam("amount") double amount,
			@RequestParam("tranType") String tranType, @RequestParam("tranStatus") String tranStatus, Model model,
			HttpSession session) {
		int userId = 0;
		userId = (int) session.getAttribute("userId");
		if (userId == 0) {
			return "SessionExpired";
		}
		// System.out.println(cusId);

		Transaction tran = new Transaction();
		tran.setTranFromAccount(fromAccNumber);
		tran.setTranToAccount(toAccNumber);
		tran.setTranAmount(amount);
		tran.setTranType(tranType);
		tran.setTranStatus(tranStatus);

		int status;
		try {

			ResponseEntity<Transaction> res = restTemplate
					.postForEntity("http://localhost:8095/transactionservice/create", tran, Transaction.class);
			Transaction transaction = (Transaction) res.getBody();
			System.out.println(transaction);
			System.out.println(res.getStatusCodeValue());
			return "redirect:/transactions";
		} catch (Exception e) {

			status = 400;
			model.addAttribute("message", "UserName and Password invalid" + e);

			return "home";
		}

	}

	
	// update customer
	@PostMapping("/updatecustomer")
	public String updateCustomer(@RequestParam("cusId") int cusId, @RequestParam("cusName") String cusName,
			@RequestParam("cusEmail") String cusEmail, @RequestParam("cusMob") long cusMob,
			@RequestParam("cusAadhar") long cusAadhar, @RequestParam("cusPermaAdd") String cusPermaAdd,
			@RequestParam("cusResiAdd") String cusResiAdd, @RequestParam("cusDob") String cusDob, Model model,
			HttpSession session) {
		System.out.println(cusId);
		Customer cus = new Customer();
		cus.setCusId(cusId);
		cus.setCusName(cusName);
		cus.setCusEmail(cusEmail);
		cus.setCusMob(cusMob);
		cus.setCusAadhar(cusAadhar);
		cus.setCusPrmaAdd(cusPermaAdd);
		cus.setCusResiAdd(cusResiAdd);
		cus.setCusDob(cusDob);
		int status;
		try {

			ResponseEntity<Customer> res = restTemplate.postForEntity("http://localhost:8084/customerservice/update",
					cus, Customer.class);
			Customer customer = (Customer) res.getBody();
			System.out.println(customer);

			System.out.println(res.getStatusCodeValue());
			return "redirect:/customers";

		} catch (Exception e) {

			status = 400;
			model.addAttribute("message", "UserName and Password invalid" + e);

			return "home";
		}

	}

	
	//Update Account
	@PostMapping("/updateAccount")
	public String updateAccount(@RequestParam("accNumber") long accNumber,
			@RequestParam("accBalance") double accBalance, @RequestParam("accBranch") String accBranch,
			// @RequestParam("accOpenDate") LocalDate accOpenDate,
			@RequestParam("accType") String accType, Model model, HttpSession session) {
		int userId = 0;
		userId = (int) session.getAttribute("userId");
		if (userId == 0) {
			return "SessionExpired";
		}

		Account acc = new Account();
		acc.setAccNumber(accNumber);
		acc.setAccBalance(accBalance);
		acc.setAccBranch(accBranch);
		acc.setAccType(accType);

		int status;
		try {

			ResponseEntity<Account> res = restTemplate.postForEntity("http://localhost:8085/accountservice/update", acc,
					Account.class);
			Account account = (Account) res.getBody();
			System.out.println(account);
			;
			System.out.println(res.getStatusCodeValue());
			return "redirect:/accounts";
		} catch (Exception e) {

			status = 400;
			model.addAttribute("message", "UserName and Password invalid" + e);

			return "home";
		}

	}

	
	// delete customer
	@GetMapping("/deletecustomer/{cusId}")
	public String deleteCustomer(@PathVariable("cusId") int cusId) {
		restTemplate.delete("http://localhost:8084/customerservice/delete/" + cusId);
		return "redirect:/customers";
	}

	// delete Account
	@GetMapping("/deleteaccount/{accnum}")
	public String deleteAccount(@PathVariable("accnum") long accNum) {
		restTemplate.delete("http://localhost:8085/accountservice/delete/" + accNum);
		return "redirect:/accounts";
	}

	// delete Transaction
	@GetMapping("/deletetransaction/{tranId}")
	public String deleteTransaction(@PathVariable("tranId") int tranId) {
		restTemplate.delete("http://localhost:8095/transactionservice/delete/" + tranId);
		return "redirect:/transactions";
	}

	
	// Deposit Method
	@GetMapping("/deposit")
	public String depositAccount(@RequestParam("accNumber") long accNum, @RequestParam("amount") double amount)
			throws AccountNotFoundException {
		System.out.println(accNum + " " + amount);
		restTemplate.getForObject("http://localhost:8085/accountservice/deposit/" + accNum + "/" + amount,
				Object.class);
		
        try {
        	Transaction transaction = new Transaction();
    		transaction.setTranFromAccount(accNum);
    		transaction.setTranAmount(amount);
    		transaction.setTranStatus("success");
    		transaction.setTranType("Deposit");
		ResponseEntity<Object> res = restTemplate.postForEntity("http://localhost:8095/transactionservice/create",
				transaction, Object.class);
		Transaction transaction1 = (Transaction) res.getBody();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/accounts";
        }catch(Exception e) {
        	Transaction transaction = new Transaction();
    		transaction.setTranFromAccount(accNum);
    		transaction.setTranAmount(amount);
    		transaction.setTranStatus("Failed");
    		transaction.setTranType("Deposit");
		ResponseEntity<Object> res = restTemplate.postForEntity("http://localhost:8095/transactionservice/create",
				transaction, Object.class);
		Transaction transaction1 = (Transaction) res.getBody();
        	return e.getMessage();
        }

	}

	// Withdraw Method
	@GetMapping("/withdraw")
	public String withdrawAccount(@RequestParam("accNumber") long accNum, @RequestParam("amount") double amount) {
		System.out.println(accNum + " " + amount);
		restTemplate.getForObject("http://localhost:8085/accountservice/withdraw/" + accNum + "/" + amount,
				Object.class);
		Transaction transaction = new Transaction();
		transaction.setTranFromAccount(accNum);
		transaction.setTranAmount(amount);
		transaction.setTranStatus("success");
		transaction.setTranType("Withdraw");
		ResponseEntity<Object> res = restTemplate.postForEntity("http://localhost:8095/transactionservice/create",
				transaction, Object.class);
		Transaction transaction1 = (Transaction) res.getBody();
		System.out.println(res.getStatusCodeValue());

		return "redirect:/accounts";
	}

	
	
	// Fund Transfer
	@GetMapping("/fundtransfer")
	public String fundtransferAccount(@RequestParam("fromAccNumber") long fromAccNum,
			@RequestParam("toAccNumber") long toAccNum, @RequestParam("amount") double amount) {
		restTemplate.getForObject(
				"http://localhost:8085/accountservice/fundtransfer/" + fromAccNum + "/" + toAccNum + "/" + amount,
				Object.class);

		Transaction transaction = new Transaction();
		transaction.setTranFromAccount(fromAccNum);
		transaction.setTranToAccount(toAccNum);
		transaction.setTranAmount(amount);
		transaction.setTranStatus("success");
		transaction.setTranType("Fund Transfer");
		ResponseEntity<Object> res = restTemplate.postForEntity("http://localhost:8095/transactionservice/create",
				transaction, Object.class);
		Transaction transaction1 = (Transaction) res.getBody();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/accounts";
	}

}
