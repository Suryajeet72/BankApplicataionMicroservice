package com.banking.customerservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.customerservice.dao.CustomerDao;
import com.banking.customerservice.exception.NoRecordsException;
import com.banking.customerservice.model.Customer;

@Service
public class CustomerService {

	@Autowired
	private CustomerDao dao;

	public boolean addCustomer(Customer cust) {
		Customer cus = dao.save(cust);
		if (cus != null)
			return true;
		else
			return false;
	}

	public boolean updateCustomer(Customer cust) {
		Customer cus = dao.save(cust);
		if (cus != null)
			return true;
		else
			return false;
	}

	public List<Customer> getAllCustomer() {
		List<Customer> list = dao.findAll();
		if (list.isEmpty()) {
			throw new NoRecordsException("No records found");
		} else {
			return list;
		}
	}

	public boolean deleteCustomer(int cusId) {
		
		Optional<Customer> cus = dao.findById(cusId);
		Customer custdb1 = cus.get();
		if (custdb1 != null) {
			dao.deleteById(cusId);
			return true;
		} else {
			throw new NoRecordsException("No record to delete");
		}
	}

	public boolean deleteAll() {
		dao.deleteAll();
		return true;
	}

}
